package controllers

import (
	"encoding/json"
	"net/http"
	"strings"

	"github.com/LifeBank/src/process"
)

func ProductsController(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	auth := strings.SplitN(r.Header.Get("Authorization"), " ", 2)
	tknStr := auth[1]

	httpCode, c := process.ListProducts(tknStr)
	if httpCode != http.StatusOK {
		w.WriteHeader(httpCode)
		return
	}

	json.NewEncoder(w).Encode(c)
}
