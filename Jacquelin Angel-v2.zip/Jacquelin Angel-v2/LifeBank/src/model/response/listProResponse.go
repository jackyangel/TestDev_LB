package response

type Product struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}

type ListProductsRes struct {
	Accounts map[string][]Product `json:"Account"`
}
