package response

type LBLoginResponse struct {
	Token string `json:"tkn"`
}
