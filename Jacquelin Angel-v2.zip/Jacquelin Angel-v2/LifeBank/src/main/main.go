package main

import (
	handler "github.com/LifeBank/src/handler"
)

func main() {
	handler.StartServer()
}
