package process

import (
	"net/http"

	r "github.com/LifeBank/src/model/response"
	"github.com/LifeBank/src/repository"
	"github.com/LifeBank/src/utils"
	"github.com/dgrijalva/jwt-go"
)

func ListProducts(tknStr string) (httpCode int, json r.ListProductsRes) {

	client, token, err := utils.GetToken(tknStr)

	if !token.Valid {
		//"el tiempo a expirado"
		httpCode = http.StatusUnauthorized
		return
	}

	if err != nil {
		if err == jwt.ErrSignatureInvalid {
			//"firma invalida"
			httpCode = http.StatusUnauthorized
			return
		}
		//"ocurrio un error"
		httpCode = http.StatusBadRequest
		return
	}

	json, err = GetListProducts(client)
	if err != nil {
		httpCode = http.StatusBadRequest
	}

	httpCode = http.StatusOK
	return
}

func GetListProducts(cli int) (lsProducts r.ListProductsRes, err error) {

	rows, err := repository.GetListPro(cli)
	if err != nil {
		return
	}

	listP := make(map[string][]r.Product)

	var product, id, name string

	for rows.Next() {
		rows.Scan(&product, &id, &name)
		listP[product] = append(listP[product], r.Product{id, name})
	}
	lsProducts = r.ListProductsRes{Accounts: listP}

	return
}
