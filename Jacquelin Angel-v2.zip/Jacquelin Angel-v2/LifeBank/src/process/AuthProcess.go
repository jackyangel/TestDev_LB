package process

import (
	"net/http"

	"github.com/LifeBank/src/model/entity"
	"github.com/jinzhu/gorm"

	"github.com/LifeBank/src/model/request"
	"github.com/LifeBank/src/model/response"
	"github.com/LifeBank/src/repository"
	"github.com/LifeBank/src/utils"
)

func Authentication(u request.LBLoginRequest, ip string) (httpCode int, tkn response.LBLoginResponse) {
	//cifrar password...
	encryptedPass := utils.CodePass(u.User, u.Password)
	//fmt.Println("sha512: " + encryptedPass)

	userResult, err := repository.ValidateU(u.User)

	//si no se encontro ningun registro de ese usuario
	if gorm.IsRecordNotFoundError(err) {
		httpCode = http.StatusNotFound
		return
	}

	//si la cuenta de usuario esta bloqueada
	if userResult.Locked != 0 {
		httpCode = http.StatusBadRequest
		return
	}
	//si hay error en las credenciales
	if encryptedPass != userResult.Password {
		//incrementar # intentos
		addTry(userResult.NameUser, userResult.NumAttemps)
		httpCode = http.StatusUnauthorized
		return
	}
	//Obtener el jwt
	tkn.Token, err = utils.Generatejwt(userResult.IdClient, ip)
	if err != nil {
		httpCode = http.StatusInternalServerError
		return
	}
	httpCode = http.StatusOK
	return
}

func addTry(user string, attempts int) {
	sum := attempts + 1
	updateUser := entity.LBUserEntity{
		NumAttemps: sum}
	if sum == 5 {
		updateUser.Locked = 1
	}

	repository.SaveSignIn(user, updateUser)
}
