package repository

import (
	"fmt"
	"log"

	entity "github.com/LifeBank/src/model/entity"
)

func ValidateU(username string) (user entity.LBUserEntity, err error) {

	db, err := GetDBConnection()
	if err != nil {
		fmt.Println(err.Error())
		panic("Falló la conexión")
		return
	}
	defer db.Close()
	u := entity.LBUserEntity{NameUser: username}
	err = db.Where(&u).First(&user).Error
	return
}

func SaveSignIn(username string, upUser entity.LBUserEntity) (err error) {

	db, err := GetDBConnection()
	if err != nil {
		fmt.Println(err.Error())
		panic("Falló la conexión")
		return
	}
	defer db.Close()
	u := entity.LBUserEntity{NameUser: username}

	err = db.Model(&u).Update(upUser).Error
	return
}

func GetIdClient(username string) {

	db, err := GetDBConnection()
	if err != nil {
		log.Fatal(err.Error())
		panic("Falló la conexión")
		return
	}
	defer db.Close()

	user := entity.LBUserFKEntity{}

	rows, _ := db.Table("users").Select("client.name").Joins("inner join client on  users.id_client = client.id_client").Where("users.name_user = ?", username).Rows()
	for rows.Next() {
		rows.Scan(&user.Client.Name)
		fmt.Println(user.Client.Name)
	}
	return
}
