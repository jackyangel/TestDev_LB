package repository

import (
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/mysql"
)

func GetDBConnection() (database *gorm.DB, err error) {

	dbDriver := "mysql"
	dbUser := "root"
	dbPass := ""
	dbUrl := "@/lb"

	database, err = gorm.Open(dbDriver, dbUser+":"+dbPass+dbUrl+"?parseTime=true")
	return
}
