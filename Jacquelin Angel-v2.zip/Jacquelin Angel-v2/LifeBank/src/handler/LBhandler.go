package handler

import (
	"fmt"
	"net/http"

	controllers "github.com/LifeBank/src/controller"
	"github.com/gorilla/mux"
)

func StartServer() {

	port := ":8080"

	// Iniciando ruteo
	r := mux.NewRouter()

	r.HandleFunc("/SignIn", controllers.SignInController).Methods("POST")
	r.HandleFunc("/Myproducts", controllers.ProductsController).Methods("GET")
	fmt.Println("Iniciando Servidor...")
	// Iniciando servidor
	http.ListenAndServe(port, r)
}
