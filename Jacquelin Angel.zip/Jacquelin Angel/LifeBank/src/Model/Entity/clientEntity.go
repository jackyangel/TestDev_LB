package LBEntity

import "time"

type LBClientEntity struct {
	IdClient  int       `gorm:"column:LB_CL_IDCLIENT;PRIMARY_KEY; AUTO_INCREMENT"`
	Name      string    `gorm:"column:LB_CL_NAME;type:varchar(100)"`
	Lastname  string    `gorm:"column:LB_CL_LASTNAME;type:varchar(100)"`
	Document  string    `gorm:"column:LB_CL_DOCUMENT;type:varchar(9)"`
	Birth     time.Time `gorm:"column:LB_CL_BIRTH;type:varchar(9)"`
	CreatedAt time.Time `gorm:"column:PAC_CL_CREATEDDATE;type:timestamp"`
	UpdatedAt time.Time `gorm:"column:PAC_CL_MODIFIEDDATE;type:timestamp"`
}

func (u *LBClientEntity) TableName() string {
	return "LB_CL_CLIENT"
}
