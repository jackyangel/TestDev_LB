package LBEntity

import "time"

type LBSessionEntity struct {
	IdSession  int            `gorm:"column:LB_SE_SESSION;PRIMARY_KEY; AUTO_INCREMENT"`
	Client     LBClientEntity `gorm:"column:LB_SE_IDCLIENT;foreignkey:UserRefer"`
	Username   string         `gorm:column:LB_SE_USERNAME`
	Password   string         `gorm:column:LB_SE_PASSWORD`
	NumAttemps int            `gorm:column:LB_SE_NUMATTEMPS`
	locked     int            `gorm:column:LB_SE_NUMATTEMPS`
	CreatedAt  time.Time      `gorm:"column:LB_SE_CREATEDDATE;type:timestamp"`
	UpdatedAt  time.Time      `gorm:"column:LB_SE_MODIFIEDDATE;type:timestamp"`
}

func (u *LBSessionEntity) TableName() string {
	return "LB_SE_SESSION"
}
