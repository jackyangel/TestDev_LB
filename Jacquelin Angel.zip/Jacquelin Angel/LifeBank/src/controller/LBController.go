package controllers

import "net/http"

func Initcontroller(w http.ResponseWriter, r *http.Request) {

}
