package handler

import (
	"fmt"
	"net/http"

	controllers "github.com/LifeBank/src/controller"
	"github.com/gorilla/mux"
)

func hadleRequest() {

	port := "8080"
	endpoint := "/LifeBank"

	// Iniciando ruteo
	r := mux.NewRouter()
	r.HandleFunc(endpoint, controllers.Initcontroller).Methods("POST")
	fmt.Println("Iniciando Servidor...")
	// Iniciando servidor
	http.ListenAndServe(port, r)
}
