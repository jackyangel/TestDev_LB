package main

import (
	"fmt"
)

func main() {
	fmt.Println("iniciando servidor...")
}
